use crossterm::event::{self, Event, KeyCode, KeyEvent};
use crossterm::terminal::{enable_raw_mode, disable_raw_mode};
use std::collections::HashMap;

pub fn enable_input(){
    enable_raw_mode().ok();
}

pub fn disable_input(){
    disable_raw_mode().ok();
}

pub fn get_input() -> HashMap<&'static str, bool> {

    let mut input_state = HashMap::from([

        ("left", false),
                                        ("right", false),
                                        ("up", false),
                                        ("down", false),
                                        ("space", false),
                                        ("backspace", false),
                                        ("1", false),
                                        ("2", false),
                                        ("3", false),
                                        ("4", false),

    ]);

    while event::poll(std::time::Duration::from_millis(0)).unwrap_or(false) {

        if let Ok(Event::Key(KeyEvent { code, .. })) = event::read() {

            match code {

                KeyCode::Left => input_state.insert("left", true),
                KeyCode::Right => input_state.insert("right", true),
                KeyCode::Up => input_state.insert("up", true),
                KeyCode::Down => input_state.insert("down", true),
                KeyCode::Char(' ') => input_state.insert("space", true),
                KeyCode::Backspace => input_state.insert("back", true),
                KeyCode::Char('1') => input_state.insert("1", true),
                KeyCode::Char('2') => input_state.insert("2", true),
                KeyCode::Char('3') => input_state.insert("3", true),
                KeyCode::Char('4') => input_state.insert("4", true),
                _ => None,

            };

        }

    }

    input_state

}
