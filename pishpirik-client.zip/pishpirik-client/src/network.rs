use std::{collections::HashMap, net::{SocketAddr, UdpSocket}};

use crate::ecs;

pub struct Client {
    pub player_num: Option<u8>,
    pub socket: UdpSocket,
    pub server_addr: SocketAddr,
    pub entities: ecs::Entities
}

impl Client {
    pub fn new(bind_addr: &str, server_addr: &str) -> std::io::Result<Self> {
        let socket = UdpSocket::bind(bind_addr)?;
        socket.set_nonblocking(true)?;
        let server_addr: SocketAddr = server_addr.parse().expect("Invalid server address\r");

        Ok(Client {
            player_num: None,
            socket: socket,
            server_addr: server_addr,
            entities: HashMap::new() })
    }

    pub fn connect(&mut self) -> std::io::Result<()> {
        // Send empty packet to initiate connection
        self.socket.send_to(&[], &self.server_addr)?;
        Ok(())
    }

    pub fn poll(&mut self) -> std::io::Result<()> {
        let mut buf = [0; 4096]; // Adjust buffer size as needed

        match self.socket.recv_from(&mut buf) {
            Ok((size, src_addr)) => {
                if src_addr == self.server_addr {
                    println!("received message from server\r");
                    // First check if this is a player ID assignment (single byte)
                    if size == 1 && self.player_num.is_none() {
                        self.player_num = Some(buf[0]);
                        if let Some(player_num) = self.player_num {
                            println!("got assigned player num: {}\r", player_num);
                        } else {
                            println!("failed to get player num assigned: was none\r");
                        }
                    }
                    // Otherwise treat as entity update
                    else {
                        if let Ok(entities) = serde_json::from_slice::<ecs::Entities>(&buf[..size]) {
                            println!("received entities\r");
                            self.entities = entities;
                        }
                    }
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                // No data available, this is expected with non-blocking sockets
            }
            Err(e) => return Err(e),
        }

        Ok(())
    }

    pub fn send_input(&mut self, input: u8) -> std::io::Result<()> {
        if let Some(_) = self.player_num { // if already connected fully
            self.socket.send_to(&[input; 1], &self.server_addr)?;
        }
        Ok(())
    }
}
