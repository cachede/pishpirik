use crate::ecs;

pub fn render(entities: &ecs::Entities, player_num: &Option<u8>) {
    println!("\r");
    println!("------------------------------------------\r");
    println!("\r");
    let mut temp_active_player = 0;
    if let Some(games) = entities.get("games") {
        if let Some(game) = games.get(0) {
            if let Some(ecs::Components::I(active_player)) = game.get("active player") {
                temp_active_player = (*active_player-1) as u8;
            } else {
                println!("failed to get active player from game\r");
                return
            }
        } else {
            println!("failed to get game from games\r");
            return
        }
    } else {
        println!("failed to get games from entities\r");
        return
    }
    let mut my_turn = false;
    if let Some(self_player_num) = player_num {
        println!("i am player {}\r", self_player_num);
        println!("active player is {}\r", temp_active_player);
        if *self_player_num == temp_active_player {
            my_turn = true;
        }
    } else {
        println!("failed to get my player num\r");
        return
    }
    let mut top_card = None;
    if let Some(games) = entities.get("games") {
        if let Some(game) = games.get(0) {
            if let Some(ecs::Components::V(discard_pile)) = game.get("discard pile") {
                top_card = discard_pile.last();
            } else {
                println!("failed to get discard pile from game\r");
                return
            }
        } else {
            println!("failed to get game from games\r");
            return
        }
    } else {
        println!("failed to get games from entities\r");
        return
    }
    if let Some(card) = top_card {
        if my_turn {
            if let (Some(value), Some(color)) = (card.get("value"), card.get("color")) {
                println!("top card is {} of {}\r", value, color);
                println!("\r");
            } else {
                println!("failed to get value and color of top card\r");
                return
            }
            if let Some(players) = entities.get("players") {
                for player in players {
                    if let Some(ecs::Components::I(this_player_num)) = player.get("number") {
                        if let Some(my_player_num) = player_num {
                            if (*this_player_num-1) as u8 == *my_player_num {
                                if let Some(ecs::Components::V(hand)) = player.get("hand") {
                                    for (index, card) in hand.iter().enumerate() {
                                        if let (Some(value), Some(color)) = (card.get("value"), card.get("color")) {
                                            println!("{}: {} of {}\r", index, value, color);
                                        } else {
                                            println!("failed to get value and color of the {} card in my hand\r", index);
                                            return
                                        }
                                    }
                                } else {
                                    println!("failed to get my hand\r");
                                    return
                                }
                            } else {
                                println!("i am player {} not {}\r", my_player_num, this_player_num);
                            }
                        } else {
                            println!("failed to get my own player num\r");
                            return
                        }
                    } else {
                        println!("failed to get number from player\r");
                        return
                    }
                }
            } else {
                println!("failed to get players from entitites\r");
                return
            }
        } else {
            println!("it is not my turn right now...\r");
        }
    } else {
        println!("failed to get top card\r");
        return
    }
}
