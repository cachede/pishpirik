use crate::ecs;

pub fn render(entities: &ecs::Entities) {

}
