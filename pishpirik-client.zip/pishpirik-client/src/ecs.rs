use serde::{Serialize, Deserialize};
use std::collections::HashMap;
use std::fmt;

#[derive(Serialize, Deserialize, Clone)]
pub enum Components {

    B(bool),
    I(i32),
    S(String),
    V(Vec<HashMap<String, Components>>)

}

impl fmt::Display for Components {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Components::B(b) => write!(f, "{}", b),
            Components::I(i) => write!(f, "{}", i),
            Components::S(s) => write!(f, "{}", s),
            Components::V(_) => write!(f, "vector")
        }
    }
}

pub type Entities = HashMap<String, Vec<HashMap<String, Components>>>;
