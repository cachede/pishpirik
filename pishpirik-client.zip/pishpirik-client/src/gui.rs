use eframe::egui;
use crate::ecs;

pub fn render_ui(ctx: &egui::Context, entities: &ecs::Entities, player_num: &Option<u8>) {
    egui::CentralPanel::default().show(ctx, |ui| {
        ui.heading("Card Game");

        // Game status
        if let Some(games) = entities.get("games") {
            if let Some(game) = games.get(0) {
                if let Some(ecs::Components::I(active_player)) = game.get("active player") {
                    ui.label(format!("Active player: {}", active_player));

                    // Show whose turn it is
                    if let Some(p_num) = player_num {
                        if (*active_player - 1) as u8 == *p_num {
                            ui.label("It's your turn!");
                        } else {
                            ui.label("Waiting for other player...");
                        }
                    }
                }

                // Show discard pile
                if let Some(ecs::Components::V(discard_pile)) = game.get("discard pile") {
                    if let Some(top_card) = discard_pile.last() {
                        if let (Some(value), Some(color)) = (top_card.get("value"), top_card.get("color")) {
                            ui.label(format!("Top card: {} of {}", value, color));
                        }
                    }
                }
            }
        }

        // Player's hand
        if let Some(p_num) = player_num {
            if let Some(players) = entities.get("players") {
                for player in players {
                    if let Some(ecs::Components::I(this_player_num)) = player.get("number") {
                        if (*this_player_num - 1) as u8 == *p_num {
                            if let Some(ecs::Components::V(hand)) = player.get("hand") {
                                ui.separator();
                                ui.heading("Your cards:");
                                for (index, card) in hand.iter().enumerate() {
                                    if let (Some(value), Some(color)) = (card.get("value"), card.get("color")) {
                                        if ui.button(format!("{} of {}", value, color)).clicked() {
                                            // Handle card play here
                                            println!("Card {} clicked", index);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    });
}
