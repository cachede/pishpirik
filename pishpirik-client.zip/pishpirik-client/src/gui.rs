use eframe::egui::{self, Image};
use crate::{ecs, network, CardImages};

pub fn render_ui(ctx: &egui::Context, entities: &ecs::Entities, client: &network::Client, card_images: &CardImages) {
    egui::CentralPanel::default().show(ctx, |ui| {

        let mut draw_pile_empty = false;
        let mut draw_pile_size: usize = 0;
        let mut all_hands_empty = true;

        if let Some(games) = entities.get("games") {
            if let Some(game) = games.get(0) {
                if let Some(ecs::Components::V(draw_pile)) = game.get("draw pile") {
                    draw_pile_size = draw_pile.len();
                    if draw_pile.len() <= 0 {
                        draw_pile_empty = true;
                    }
                }
            }
        }

        if let Some(players) = entities.get("players"){

            for player in players{

                if let Some(ecs::Components::V(hand)) = player.get("hand"){

                    if !hand.is_empty(){

                        all_hands_empty = false

                    }

                }

            }

        }

        if draw_pile_empty && all_hands_empty {

            ui.heading("Game Ended");

            if let Some(players) = entities.get("players") {
                let mut players_points = vec![];
                for player in players {
                    if let (Some(ecs::Components::I(this_player_num)), Some(ecs::Components::I(points))) = (player.get("number"), player.get("points")) {
                        players_points.push((this_player_num, points));
                    }
                }

                // sort by points
                players_points.sort_by(|a, b| b.1.cmp(&a.1));

                let winner = players_points[0];

                for (player_num, points) in &players_points {
                    if let Some(my_player_num) = client.player_num {
                        if (my_player_num + 1) == **player_num as u8 {
                            ui.label(egui::RichText::new(format!("Player {} got {} Points", player_num, points)).color(egui::Color32::GREEN));
                        } else {
                            ui.label(format!("Player {} got {} Points", player_num, points));
                        }
                    }
                    ui.separator();
                }

                if let Some(my_player_num) = client.player_num {
                    if (my_player_num + 1) == *winner.0 as u8 {
                        ui.label("YOU WON!");
                    } else {
                        ui.label("YOU LOST!");
                    }
                }
            }

        } else {
            ui.horizontal(|ui| {
                if let Some(num) = client.player_num {
                    ui.heading(format!("Player {}    Round {}/3", num+1, 3 - (draw_pile_size / 16)));
                }

                ui.with_layout(egui::Layout::right_to_left(egui::Align::Min), |ui| {
                    if let Some(num) = client.player_num {
                        if let Some(players) = entities.get("players") {
                            for player in players {
                                if let Some(ecs::Components::I(this_player_num))= player.get("number") {
                                    if (*this_player_num - 1) as u8 == num {
                                        if let Some(ecs::Components::I(points)) = player.get("points") {
                                            ui.label(format!("points: {}", points));
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            });

            // Game status
            if let Some(games) = entities.get("games") {
                if let Some(game) = games.get(0) {
                    if let Some(ecs::Components::I(active_player)) = game.get("active player") {
                        ui.label(format!("Active player: {}", active_player));

                        // Show whose turn it is
                        if let Some(p_num) = client.player_num {
                            if (*active_player - 1) as u8 == p_num {
                                ui.label(egui::RichText::new("It's your turn!").color(egui::Color32::GREEN));
                            } else {
                                ui.label(egui::RichText::new("Waiting for other player...").color(egui::Color32::RED));
                            }
                        }
                    }

                    // Show discard pile
                    if let Some(ecs::Components::V(discard_pile)) = game.get("discard pile") {
                        if let Some(top_card) = discard_pile.last() {
                            if let (Some(ecs::Components::S(value)), Some(ecs::Components::S(color))) = (top_card.get("value"), top_card.get("color")) {
                                if let Some(image) = card_images.get(value, color) {
                                    ui.add(Image::new(image).max_height(100.0));
                                }
                            }
                        }
                    }
                }
            }

            // Player's hand
            if let Some(p_num) = client.player_num {
                if let Some(players) = entities.get("players") {
                    for player in players {
                        if let Some(ecs::Components::I(this_player_num)) = player.get("number") {
                            if (*this_player_num - 1) as u8 == p_num {
                                if let Some(ecs::Components::V(hand)) = player.get("hand") {
                                    ui.separator();
                                    ui.heading("Your cards:");
                                    ui.horizontal(|ui| {
                                        for (index, card) in hand.iter().enumerate() {
                                            if let (Some(ecs::Components::S(value)), Some(ecs::Components::S(color))) = (card.get("value"), card.get("color")) {
                                                if let Some(image) = card_images.get(value, color) {
                                                    if ui.add(Image::new(image).max_height(100.0)).clicked() {
                                                        let _ = client.send_input(index as u8 + 1);
                                                    }
                                                }
                                            }
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    });
}
