use std::process::exit;

mod network;
mod ecs;
mod input;
mod output;

fn main() -> std::io::Result<()> {
    println!("connecting to server");
    let mut client = network::Client::new("0.0.0.0:0", "127.0.0.1:37545")?;
    client.connect()?;

    std::thread::sleep(std::time::Duration::from_millis(100));

    match client.poll() {
        Ok(_) => (),
        Err(e) => println!("failed to poll connection {}", e)
    }

    input::enable_input();

    loop {
        match client.poll() {
            Ok(_) => (),
            Err(e) => println!("failed to poll connection {}\r", e)
        }

        let input = input::get_input();

        if let Some(true) = input.get("1") {
            match client.send_input(1) {
                Ok(_) => (),
                Err(e) => println!("failed to send input to server: {}\r", e)
            }
        }
        if let Some(true) = input.get("2") {
            match client.send_input(2) {
                Ok(_) => (),
                Err(e) => println!("failed to send input to server: {}\r", e)
            }
        }
        if let Some(true) = input.get("3") {
            match client.send_input(3) {
                Ok(_) => (),
                Err(e) => println!("failed to send input to server: {}\r", e)
            }
        }
        if let Some(true) = input.get("4") {
            match client.send_input(4) {
                Ok(_) => (),
                Err(e) => println!("failed to send input to server: {}\r", e)
            }
        }

        if let Some(true) = input.get("back") {
            input::disable_input();
            exit(0);
        }

        output::render(&client.entities);
    }
}
