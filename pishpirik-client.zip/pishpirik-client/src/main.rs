use std::process::exit;
use std::env;
use eframe::{egui, Frame};
use std::collections::HashMap;

mod network;
mod ecs;
mod input;
mod output;
mod gui;

struct MyEguiApp {
    client: network::Client,
    card_images: CardImages,
}

impl eframe::App for MyEguiApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut Frame) {

        ctx.request_repaint();

        match self.client.poll() {
            Ok(_) => (),
            Err(e) => println!("Failed to poll connection: {}", e)
        }

        // Render the game UI
        gui::render_ui(ctx, &self.client.entities, &self.client, &self.card_images);

        // Handle input through egui
        ctx.input(|i| {
            if i.key_pressed(egui::Key::Num1) {
                self.client.send_input(1).ok();
            }
            if i.key_pressed(egui::Key::Num2) {
                self.client.send_input(2).ok();
            }
            if i.key_pressed(egui::Key::Num3) {
                self.client.send_input(3).ok();
            }
            if i.key_pressed(egui::Key::Num4) {
                self.client.send_input(4).ok();
            }
        });
    }
}

struct CardImages {
    images: HashMap<String, egui::TextureHandle>,
}


impl CardImages {
    pub fn new(ctx: &egui::Context) -> Self {
        let mut images = HashMap::new();

        // List all card variations
        let values = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king", "ace"];
        let colors = ["clubs", "diamonds", "hearts", "spades"];

        for value in values {
            for color in colors {
                let card_name = format!("{}_of_{}", value, color);
                if let Ok(image) = load_image_from_path(format!("assets/{}.png", card_name)) {
                    let texture = ctx.load_texture(
                        &card_name,
                        image,
                        Default::default()
                    );
                    images.insert(card_name, texture);
                } else {
                    panic!("could not find card assets/{}_of_{}.png", value, color);
                }
            }
        }

        Self { images }
    }

    pub fn get(&self, value: &str, color: &str) -> Option<&egui::TextureHandle> {
        let key = format!("{}_of_{}", value.to_lowercase(), color.to_lowercase());
        self.images.get(&key)
    }
}

fn load_image_from_path(path: impl AsRef<std::path::Path>) -> Result<egui::ColorImage, image::ImageError> {
    let image = image::io::Reader::open(path)?.decode()?;
    let size = [image.width() as _, image.height() as _];
    let image_buffer = image.to_rgba8();
    let pixels = image_buffer.as_flat_samples();
    Ok(egui::ColorImage::from_rgba_unmultiplied(
        size,
        pixels.as_slice(),
    ))
}

fn main() -> std::io::Result<()> {
    let args: Vec<String> = env::args().collect();

    if args.len() != 2 {
        eprintln!("Usage: {} <ip_address>", args[0]);
        exit(1);
    }

    println!("connecting to server");
    let server_ip = &args[1];
    let server_addr = format!("{}:37545", server_ip);
    let mut client = network::Client::new("0.0.0.0:0", &server_addr)?;
    client.connect()?;

    std::thread::sleep(std::time::Duration::from_millis(1000));

    match client.poll() {
        Ok(_) => (),
        Err(e) => println!("failed to poll connection {}", e)
    }

    if client.player_num.is_none() {
        eprintln!("failed to connect to server");
        exit(1);
    }

    let options = eframe::NativeOptions::default();
    eframe::run_native(
        "Pishpirik",
        options,
        Box::new(|cc| {
            // Initialize card images once
            let card_images = CardImages::new(&cc.egui_ctx);

            Box::new(MyEguiApp {
                client,
                card_images,
            })
        }),
    ).unwrap();

    Ok(())
}

