use std::process::exit;
use std::env;
use eframe::{egui, Frame};

mod network;
mod ecs;
mod input;
mod output;
mod gui;

struct MyEguiApp {
    client: network::Client,
}

impl eframe::App for MyEguiApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut Frame) {

        ctx.request_repaint();

        match self.client.poll() {
            Ok(_) => (),
            Err(e) => println!("Failed to poll connection: {}", e)
        }

        // Render the game UI
        gui::render_ui(ctx, &self.client.entities, &self.client.player_num);

        // Handle input through egui
        ctx.input(|i| {
            if i.key_pressed(egui::Key::Num1) {
                self.client.send_input(1).ok();
            }
            if i.key_pressed(egui::Key::Num2) {
                self.client.send_input(2).ok();
            }
            if i.key_pressed(egui::Key::Num3) {
                self.client.send_input(3).ok();
            }
            if i.key_pressed(egui::Key::Num4) {
                self.client.send_input(4).ok();
            }
        });
    }
}

fn main() -> std::io::Result<()> {
    let args: Vec<String> = env::args().collect();

    if args.len() != 2 {
        eprintln!("Usage: {} <ip_address>", args[0]);
        exit(1);
    }

    println!("connecting to server");
    let mut client = network::Client::new("0.0.0.0:0", "127.0.0.1:37545")?;
    client.connect()?;

    std::thread::sleep(std::time::Duration::from_millis(100));

    match client.poll() {
        Ok(_) => (),
        Err(e) => println!("failed to poll connection {}", e)
    }

    if client.player_num.is_none() {
        eprintln!("failed to connect to server");
        exit(1);
    }

    let options = eframe::NativeOptions::default();
    eframe::run_native(
        "Card Game",
        options,
        Box::new(|_cc| Box::new(MyEguiApp {
            client,
        })),
    ).unwrap();

    Ok(())
}

